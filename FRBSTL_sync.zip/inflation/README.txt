 This Readme is for the data-sync scripts for the inflation calculators: inflation.py
This script will create a data.json file in the user’s exhibit directory.  Any existing data.json file will be backed up.

To run this script, first insure that required python modules are installed:
	csv, requests, sqlite3, dateutil, datetime, pytz, json
	
Run the script with python:
	$python inflation.py

Or simply double-click update.command