Data-sync Scripts for FRBSTL "Inside the Economy Museum" digital exhibit content.

These scripts are installed in $HOME/exhibit on each machine that runs one of the three exhibits: Interactive Projection, Unemployment Calculator, and Inflation Rate Calculator.

In regular use cases, python scripts can be run via OSX Finder by double-clicking update.command. Each script will make a backup of existing data before cloning the requisite data from the server.  This backup can be manually restored by removing the timestamp if the clone fails.

Ryan Nestor
Monadnock Media
ryan@monadnock.org
413.665.1390