double-click or otherwise run the update.command
a backup of the existing database will be made and a new one will be created in the User’s exhibit folder
